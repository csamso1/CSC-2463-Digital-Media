Clayton Samson
csamso1@lsu.edu

This Ardiuno program takes a hardcoded message and the code runs in the setup function so the message is only translated into morse code once.

The message for the code sumbitted is 'i love digital media' please that this version only translates lowercase letters and integers.

YouTube Video Link of Arduino in action: https://www.youtube.com/watch?v=vuElHKMHmYk